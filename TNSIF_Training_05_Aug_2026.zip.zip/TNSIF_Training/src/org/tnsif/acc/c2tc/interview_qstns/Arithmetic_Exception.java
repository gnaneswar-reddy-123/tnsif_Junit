package org.tnsif.acc.c2tc.interview_qstns;

public class Arithmetic_Exception {

	public static void main(String[] args) {
		int a = 10;
        int b = 0;

        try {
            int result = a / b;
            System.out.println("Result = " + result);
        }
        catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception: Cannot divide by zero.");
        }

        System.out.println("Program Ended Successfully.");
	}

}
